# 手工发送路径 + reviewer 回信应对

> **正常情况看 `README-SUBMIT.md` 就行**，那个是主文档（一条命令走完全流程）。
> 本文件是补篇：脚本跑不了的时候怎么手工发，以及 reviewer 回信了怎么办。

**已定：提交方案 A**（把 `ft->g` 的释放交回调用者）。
方案 B 已移入 `alt/`，**不提交**，仅作存档与 reviewer 明确要求时的备选。

---

## 1. 手工发（脚本跑不了的时候）

### 1.1 用系统的 `git send-email`

先按 `README-SUBMIT.md` §6 核对收件人（**别照抄旧清单**）：

```
To: saeedm@nvidia.com tariqt@nvidia.com mbloch@nvidia.com leonro@nvidia.com
    andrew+netdev@lunn.ch davem@davemloft.net edumazet@kernel.org
    kuba@kernel.org pabeni@redhat.com
Cc: netdev@vger.kernel.org linux-rdma@vger.kernel.org linux-kernel@vger.kernel.org
```

改完 `commit-msg.txt` 和 `cover-letter.txt` 之后，手工生成两封邮件：

```bash
cd <本包目录>

rm -rf work outgoing && mkdir -p work/drivers/net/ethernet/mellanox/mlx5/core outgoing
cp evidence/en_arfs.mainline.c work/drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
cd work
git init -q . && git add -A
git -c user.email=b@localhost -c user.name=b commit -q -m base
cp ../evidence/en_arfs.patchedA.c drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
git add -A
git -c user.email="you@example.com" -c user.name="Your Name" commit -q -s -F ../commit-msg.txt
# ↓ 这一行必须有：封面信的 From: 读的是「仓库级」ident，
#   不设的话会变成本机 git 身份（发出去没人认领）
git config user.email "you@example.com" && git config user.name "Your Name"
git format-patch --cover-letter --subject-prefix='PATCH net' -1 HEAD -o ../outgoing/
cd ..
```

然后把封面信的主题、正文、`base-commit:` 补上（脚本第 4 步干的就是这件事）：

- 主题：`[PATCH net 0/1] net/mlx5e: fix NULL pointer dereference in arfs_create_groups()`
- 正文：把 `cover-letter.txt` 的内容整段贴进去，末尾留一行 `-- `
- `base-commit: 97d73c8251226cf27cc6656b4c542869bb8c69fa`
  放在封面信**最后**、`-- ` 签名**之前**（跟 `git format-patch --base-commit=` 自己放的位置一样）

**先看一遍要发出去的东西**（`git send-email --dry-run` 只打邮件头、不打正文；
要连正文一起看，就走包内的假 sendmail `tools/preview-sendmail.sh`，
它把整封邮件打到屏幕上、**什么都不会发出去**）：

```bash
git send-email \
  --sendmail-cmd=tools/preview-sendmail.sh \
  ...（下面的完整参数）... \
  outgoing/0000-cover-letter.patch outgoing/0001-*.patch
```

最后发：

```bash
git send-email \
  --to=saeedm@nvidia.com --to=tariqt@nvidia.com --to=mbloch@nvidia.com \
  --to=leonro@nvidia.com --to=andrew+netdev@lunn.ch --to=davem@davemloft.net \
  --to=edumazet@kernel.org --to=kuba@kernel.org --to=pabeni@redhat.com \
  --cc=netdev@vger.kernel.org --cc=linux-rdma@vger.kernel.org --cc=linux-kernel@vger.kernel.org \
  --suppress-cc=self \
  --from="Your Name <you@example.com>" \
  outgoing/0000-cover-letter.patch outgoing/0001-*.patch
```

- `--suppress-cc=self`：不让 git 把你（作者）自动塞进 Cc，Cc 严格等于上面那三个列表。
- 想给自己留一份：`--to=you@example.com` 加一条。
- **不要**加 `--cover-letter`：`git send-email` 没有这个选项（它只有
  `--cc-cover` / `--to-cover`，管的是封面信的收件人）。多写这个，
  git 会把它当成「要 format-patch 的版本范围」，在**不是 git 仓库的目录**里
  直接报 `Cannot run git format-patch from outside a repository`，
  一封信都发不出去。封面信是靠 `0000-cover-letter.patch` 这个**文件**被认出来的。

### 1.2 邮件客户端直接粘贴（最后 resort）

把 `outgoing/0001-*.patch` 的**全部内容**原样作为**纯文本正文**粘贴：

- 主题：`[PATCH net] net/mlx5e: fix NULL pointer dereference in arfs_create_groups()`
- 收件人：按 §1.1
- 格式：**纯文本**（不要富文本、不要让客户端自动折行）
- **不要**手工加 `Content-Type` / `MIME-Version`
- 补丁**内联**，不要当附件

> 踩坑：网页邮箱会折行或加引用符号，破坏补丁。
> 发完在别的编辑器里核对 `@@` 段和每行的前导空格/制表符没被改。

---

## 2. 发出去之前的人工过一遍

脚本已经逐项查过（清单见 `README-SUBMIT.md` §4）。人工再扫一眼这几处：

| 看什么 | 期望 |
|---|---|
| `From:` / `Signed-off-by:` | 你的真名 + 外网能收到的邮箱，两行一致 |
| 封面信的 `From:` | 也是你（`format-patch` 造封面信读的是**仓库级** ident，容易漏） |
| `Fixes: 3c6d5189246f` | 在（netdev 对 fix 的硬要求） |
| `Tested-by:` | **不在**（我们没启动过打了补丁的内核） |
| `Reviewed-by:` / `Acked-by:` | 不在（我们没参与 review） |
| `base-commit:` | 在封面信末尾，指向 `97d73c8251226cf27cc6656b4c542869bb8c69fa` |
| 补丁能干净应用 | `git apply --check` 对 v7.4-rc2 的 `en_arfs.c`，偏移 0 |
| 打完的结果 | 与 `evidence/en_arfs.patchedA.c` 逐字节相同 |
| 正文行宽 | 没有超过 75 列的行 |
| 主题长度 | ≤ 75 列 |
| `REPORT.md` | **不要**整个贴进邮件，正文保持现在这样 |

---

## 3. reviewer 回信了怎么办

### 3.1 改代码 / 改文字 → 发 v2

```bash
# 1) 改 commit-msg.txt（和/或 evidence/en_arfs.patchedA.c）
# 2) 承认新基线（否则脚本会报「与静态参考件有出入」）
./prepare-and-send.sh --check --update-ref --identity "Your Name <you@example.com>"
# 3) 重发
./prepare-and-send.sh --send --identity "Your Name <you@example.com>"
```

规矩（`Documentation/process/maintainer-netdev.rst`）：

- 重发**另起一个线程**（不要 `In-Reply-To` 旧的），主题带版本号 `[PATCH net v2]`
- 正文写 changelog，并给出上一版的链接（lore.kernel.org 的 Message-ID 链接）
- 两次重发之间**至少隔 24 小时**
- 如果要撤掉上一版，邮件里加一行 `pw-bot: changes-requested`

### 3.2 常见的回音

| reviewer 说 | 应对 |
|---|---|
| 「应该复位 `ft->num_groups = 0;`」 | 那是方案 B，`alt/` 里有现成的。但它**只修空指针、留下 group 泄漏** —— 优先坚持方案 A（交回调用者），顺带说明：调用者 `mlx5e_destroy_flow_table()` 本来就会销毁已建成的 group 并释放 `ft->g`，所以方案 A 两个问题一起解决，且 `ft->g` 仍然只被释放一次（CVE-2024-35835 的 double free 不复活） |
| 「应该改成 `mlx5e_destroy_groups(ft); kfree(ft->g);`」 | commit message 里已经解释过：`mlx5e_destroy_flow_table()` 就是这么做的，调用者已经会销毁 group |
| 「`Fixes:` 该指别的提交」 | `3c6d5189246f` 是**引入回归**的提交（CVE-2024-35835 的那个修复），指它是对的。若 reviewer 认为该指 `1cabe6b0965e`（aRFS 流表创建），照他的改 |
| 「复现步骤要能独立于你们的固件」 | `REPORT.md` §2.6/§2.7 已经写好口径：**任何 `CREATE_FLOW_GROUP` 失败都会触发**，我们的固件只是提供了一个稳定触发源（2 s 超时 vs 宿主 60 s）。可以照这个口径回 |
| 「需要 `Tested-by:` / 你测了吗」 | 如实说：**没有启动过打了补丁的内核**，只复现了原崩溃。诚实回答比编一个 `Tested-by:` 好 |
| 「为什么不加 `ft->num_groups = 0;` 顺手修了」 | 见第一行：那会留下 group 泄漏，而且方案 A 与驱动其余部分的错误处理风格一致（`mlx5e_create_l2_table()` 就是这么写的） |
| 「这个 bug 要不要报 security list」 | 见 `maintainer-netdev.rst`：netdev 维护者明确要求**不要**单独私发给维护者，走邮件列表；不确定就问 `security@kernel.org` |

### 3.3 跟踪状态

- patchwork：<https://patchwork.kernel.org/project/netdevbpf/list/> —— 搜自己的主题
- 邮件归档：<https://lore.kernel.org/netdev/> —— 搜主题

状态 `New` / `Under review` = 进了维护者队列；`Applied` = 已被采纳；
`Changes requested` = 要发 v2；`Needs ACK` = 等人认领测试。
