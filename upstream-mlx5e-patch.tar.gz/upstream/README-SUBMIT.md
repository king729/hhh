# 上游提交指南（到有 send-email 的机器上直接发）

本包要提的是 **Linux 内核 mlx5e 驱动的空指针解引用 bug**。
补丁内容、触发链、证据链都在 `REPORT.md`；本文件只讲**怎么发出去**。

**目标树**：`net`（`[PATCH net]` 前缀，bug fix 走 net 树，不是 net-next）
**基线**：mainline `97d73c8251226cf27cc6656b4c542869bb8c69fa`（v7.4-rc2 之后）

---

## 0. 三步走

在一台**有 git send-email** 的机器上（不需要有内核源码树，不需要联网抓代码）：

```bash
cd <本包目录>
./prepare-and-send.sh --check --identity "Your Name <your.real.mail@example.com>"
./prepare-and-send.sh --dry-run --identity "Your Name <your.real.mail@example.com>"   # 看邮件长什么样，不真发
./prepare-and-send.sh --send   --identity "Your Name <your.real.mail@example.com>"   # 真发
```

- `--check`：**不生成补丁、不发送**，只做环境和内容自检。先跑这个。
- `--dry-run`：生成补丁 + 自检 + 把两封邮件**完整原文**打到屏幕上，**不连接 SMTP、不发出去**。
- `--send`：真发。发之前脚本会让你输 `yes` 再确认一次。

`--identity` 也可以不写，脚本会依次找 `$KERNEL_IDENTITY` → `git config user.name/user.email` → 交互询问。

**建议顺序**：先 `--check` 看自检全绿 → 再 `--dry-run` 逐行读一遍邮件正文 → 最后 `--send`。

> **`--dry-run` 为什么能看到完整正文？**
> `git send-email` 自己的 `--dry-run` 只打邮件头、不打正文 —— 而补丁正文
> （空白、制表符、`@@` 段）恰恰是最需要人工校对的东西。
> 所以脚本的 `--dry-run` 改走 **sendmail 路径**：把 `tools/preview-sendmail.sh`
> 当作 sendmail，git 把**整封邮件（头 + 正文）**写进它的 stdin，它原样打到屏幕上。
> **什么都不会发出去**（连 SMTP 都不连）。

### 常用可选参数

| 参数 | 作用 |
|---|---|
| `--identity "名字 <邮箱>"` | 决定 `From:` 和 `Signed-off-by:` |
| `--to-extra "you@example.com"` | 额外收件人（可重复）。netdev 规矩要求**第一次发先给自己一份**，用它 |
| `--update-ref` | 改了 `commit-msg.txt` / `cover-letter.txt` 之后，承认新基线（见 §5） |

收件人清单是**脚本里写死的**（`TO_ADDRS` / `CC_ADDRS`），来源见 §6；
脚本每次都会用 `get_maintainer.pl` 重新核对一遍。

---

## 1. 身份：整包里唯一必须你自己填的东西

`From:` 和 `Signed-off-by:` 用的是同一个身份，由 `--identity` 决定。

**必须是你真实姓名 + 一个外网能收到的邮箱**。脚本会主动拦两类错：

| 情况 | 脚本反应 |
|---|---|
| 邮箱格式不像（没有 `@` 或没有点） | 警告 |
| 邮箱域名是内网的（`.intra` / `.internal` / `.local` / `.lan`） | **报错，退出码非 0** |

内网地址发到 LKML 上没人收得到，而且内核的 maintainer bot 会因为
「`From:` 对不上 MAINTAINERS 里的维护者」而拒收，所以这一步别将就。

本机默认身份是 `root <root@LIN-6CEA3E40BA9.zte.intra>`（内网），**不能直接用**。

---

## 2. 前置条件

| 需要 | 有没有都行？ | 说明 |
|---|---|---|
| `git` | 必须 | 生成补丁靠 `git format-patch` |
| `perl` | 必须 | `git send-email` 是 perl 脚本 |
| `git send-email` | **没有也行** | 包内自带 `tools/git-send-email` + `tools/perl/`（`Mail::Address` 依赖），脚本自动用自带的 |
| 内核源码树 | 不需要 | `checkpatch.pl` 是可选的，有就多查一遍，没有就跳过 |
| 联网 | 不需要 | 代码快照、MAINTAINERS、依赖全在包里 |

脚本第 0 步会告诉你它到底用了哪个 `send-email`：

```
✓ git send-email: 系统自带（/usr/lib/git-core/git-send-email）
  或
✓ git send-email: 用包内自带件 tools/git-send-email（依赖在 tools/perl）
```

**装系统版 send-email**（可选，装了就优先用系统的）：

```bash
# Debian/Ubuntu
apt-get install git-email
# RHEL/Fedora
yum install git-email
```

---

## 3. SMTP 配置（只有 `--send` 才需要）

`git send-email` 走 SMTP。先配好：

```bash
git config --global sendemail.smtpserver smtp.example.com
git config --global sendemail.smtpport 587          # 465 = 隐式 SSL，587 = STARTTLS
git config --global sendemail.smtpauth PLAIN        # 或 LOGIN / CRAM-MD5
git config --global sendemail.smtpuser your-account
git config --global sendemail.smtppass your-password
git config --global sendemail.smtpssl required      # 587 + STARTTLS 时要
```

要认证的话，`smtppass` 建议用凭据助手而不是明文：

```bash
git config --global credential.helper store
```

脚本第 0 步会检查 `sendemail.smtpserver`：**`--send` 时缺了直接报错退出**，
`--check` / `--dry-run` 时只提醒。

**排障**：`--dry-run` 完全不连 SMTP，所以它过了不代表能发出去。
真发之前建议先单独测一下 SMTP 通不通：

```bash
python3 -c "import smtplib; s=smtplib.SMTP('smtp.example.com',587); s.starttls(); s.login('you','pw'); print('SMTP OK')"
```

---

## 4. 自检都查了什么

`--check` / `--dry-run` / `--send` 都会跑下面这些检查，全绿才继续。
**实际条数随环境变**（本机 28 行 / 27 项通过；机器上没有内核源码树时，
`checkpatch.pl` 和 `get_maintainer.pl` 两项会降级成警告，条数少 2）。
每一项不通过都会在屏幕上打 `✗` 并把退出码变成非 0。

| # | 检查项 | 不通过意味着 |
|---|---|---|
| 0 | git / perl / send-email 在位 | 装依赖 |
| 0 | SMTP 配置（`--send` 时是硬要求） | 配 SMTP |
| 1 | 身份格式对 | 改 `--identity` |
| 1 | 邮箱不是内网域名 | 换成外网能收信的地址 |
| 2 | 素材齐备（补丁源文件、commit message、cover letter） | 包不完整 |
| 3 | `git format-patch` 成功生成封面信 + 补丁 | 看 stderr |
| 4 | 封面信主题/正文占位符全部替换 | 脚本会重填 |
| 4 | `base-commit:` trailer 已加上 | 脚本会重填 |
| 4 | 封面信的 `From:` 是你的身份 | 见下面「封面信 From: 变成本机身份」 |
| 5 | 主题 ≤ 75 列 | 内核风格要求 |
| 5 | 正文没有超过 75 列的行 | 内核风格要求 |
| 5 | 有 `Fixes:` 标签 | netdev 对 fix 的**硬要求** |
| 5 | 有 `Signed-off-by:` 且与身份一致 | 上游要求 DCO |
| 5 | **没有** `Tested-by:` | 我们没跑过打了补丁的内核，写了就是假声明 |
| 5 | 与静态参考件逐字节一致（除身份/日期/版本号） | 输入被改过，见 §5 |
| 5 | 能干净应用到 mainline 的 `en_arfs.c` | 补丁坏了 |
| 6 | `checkpatch.pl` 0 errors | 内核自己的风格检查器 |
| 7 | 收件人与 `get_maintainer.pl` 的输出一致 | MAINTAINERS 变了，见 §6 |
| 8 | （`--send`）确认发送 | — |

> **「封面信 From: 变成本机身份」**：git 造封面信那一步读的是**仓库级** ident，
> 不是 commit 那条命令上的 `-c user.email=`。脚本已经在 `format-patch` 之前把
> 仓库 ident 设成你的身份，所以这条正常是绿的；如果它红了，说明脚本被改过，
> 或者你手改了生成流程。

---

## 5. 改了内容怎么办

要改的文字只有两个文件：

- `commit-msg.txt` —— 补丁的 commit message（**不含** `Signed-off-by:`，由 `git commit -s` 自动加）
- `cover-letter.txt` —— 封面信正文

代码改动在 `evidence/en_arfs.patchedA.c`（打好的成品，不用改）；
基线在 `evidence/en_arfs.mainline.c`。

改完之后静态参考件就过期了（第 5 步会报「与静态参考件有出入」并 diff 给你看）。
确认改动是有意的之后，用这条承认新基线：

```bash
./prepare-and-send.sh --check --update-ref --identity "Your Name <you@example.com>"
```

`--update-ref` 把本次生成覆盖回静态参考件，下一次跑就又全绿了。

> 静态参考件的作用是**回归护栏**：万一有人手滑改了 `evidence/` 里的文件，
> 或者 commit message 被意外改掉，diff 会立刻指出来。

---

## 6. 收件人是怎么来的 / 怎么自己复核

收件人**不是手写的**，是 `scripts/get_maintainer.pl` 对 **v7.4-rc2 的 MAINTAINERS**
跑出来的结果：maintainer 进 `To:`，mailing list 进 `Cc:`。

包内自带 `evidence/MAINTAINERS.mainline`（就是 v7.4-rc2 那份），
脚本第 7 步会自己再跑一遍 `get_maintainer.pl` 核对，MAINTAINERS 变了就会报不一致。

**你自己想复核**，在有内核源码树的机器上：

```bash
cd <内核树>
perl scripts/get_maintainer.pl -f --nogit \
    drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
```

对照本包的 `To:` / `Cc:`：

```
To: saeedm@nvidia.com tariqt@nvidia.com mbloch@nvidia.com leonro@nvidia.com
    andrew+netdev@lunn.ch davem@davemloft.net edumazet@kernel.org
    kuba@kernel.org pabeni@redhat.com
Cc: netdev@vger.kernel.org linux-rdma@vger.kernel.org linux-kernel@vger.kernel.org
```

当前结果：

```
Saeed Mahameed <saeedm@nvidia.com>   (maintainer:MELLANOX ETHERNET DRIVER (mlx5e))
Tariq Toukan <tariqt@nvidia.com>     (maintainer:MELLANOX ETHERNET DRIVER (mlx5e))
Mark Bloch <mbloch@nvidia.com>        (maintainer:MELLANOX ETHERNET DRIVER (mlx5e))
Leon Romanovsky <leonro@nvidia.com>  (maintainer:MELLANOX MLX5 core VPI driver)
Andrew Lunn <andrew+netdev@lunn.ch>  (maintainer:NETWORKING DRIVERS)
"David S. Miller" <davem@davemloft.net>
Eric Dumazet <edumazet@kernel.org>
Jakub Kicinski <kuba@kernel.org>
Paolo Abeni <pabeni@redhat.com>
netdev@vger.kernel.org   (open list)
linux-rdma@vger.kernel.org (open list)
linux-kernel@vger.kernel.org (open list)
```

---

## 7. 第一次发之前

netdev 的规矩（`Documentation/process/maintainer-netdev.rst`）：

- **第一次发补丁，先发给自己一份**，确认邮件没被改格式、补丁能干净应用。
  → 脚本默认把你自己**排除**在 Cc 之外（`--suppress-cc=self`，
  这样 Cc 严格等于 `get_maintainer.pl` 算出来的三个列表，邮件头可复现）。
  给自己那份用 `--to-extra` 加自己：
  ```bash
  ./prepare-and-send.sh --send --identity "Your Name <you@example.com>" \
      --to-extra "you@example.com"
  ```
- 24 小时内**不要重发**同一份补丁。
- 重发要**另起一个线程**（不要 `In-Reply-To` 旧的），主题里带版本号
  （`[PATCH net v2]`），正文里写 changelog 和上一版的链接。
- 补丁数不要超过 15 个（本包只有 1 个）。
- **改了补丁就别 repost**，回信里带 `pw-bot: changes-requested` 会被 bot 标记状态。

**如果你的发信服务器不让发外部地址**，或者你担心格式被改，
可以先用 `--dry-run` 把邮件内容另存成 `.eml` 再手工发——但那要你自己保证
正文没被编辑器改过（`HOW-TO-SEND.md` §1.2 有手工步骤）。

---

## 8. 发出去之后

1. **查状态**：<https://patchwork.kernel.org/project/netdevbpf/list/>
   搜自己的主题。状态 `New`/`Under review` = 进了维护者的队列。
2. **查回信**：<https://lore.kernel.org/netdev/> 搜主题。
3. **收到 review 意见**：
   - 要改代码 → 改 `commit-msg.txt` / `evidence/en_arfs.patchedA.c`，
     `--update-ref` 承认新基线，然后按 §7 的规矩重发 v2。
   - 只是问问题 → 直接回信即可，不用重发。
4. **被 Applied / Acked-by** → 补丁进了 net 树，之后会随 net 树进主线。

**本补丁没有 `Tested-by:`**，因为我们**没有启动过打了补丁的内核**——
只复现了崩溃，没验证修复。如果之后在真机上验证了修复，
可以补一条 `Tested-by:` 再发 v2。

---

## 9. 排障

| 现象 | 原因 / 怎么办 |
|---|---|
| `既没有系统 git send-email，也没有包内自带件` | 包解压不完整，`tools/` 目录没跟过来 |
| `The 'Mail::Address' module is not here` | 用了系统版 send-email 但系统缺 perl 模块；装 `libmailtools-perl` / `git-email`，或者让脚本用自带的 |
| `SMTP: 没设 sendemail.smtpserver` | 配 SMTP，见 §3 |
| `邮箱域名是内网的，外网收不到` | 换 `--identity` |
| `生成的补丁与静态参考件有出入` | 输入被改过；确认后 `--update-ref`，见 §5 |
| `收件人与 get_maintainer.pl 的输出一致` 那一行报错 | MAINTAINERS 变了（内核合了新 commit）；按 §6 重新核对并更新脚本里的 `TO_ADDRS` / `CC_ADDRS` |
| `checkpatch: 0 errors` 但有 `Unknown commit id` 警告 | 本地树没有 `3c6d5189246f` 这个 commit，不是问题 |
| 预览里的邮件头是 `root@LIN-...intra` 之类 | 身份没传进去：显式给 `--identity "名字 <外网邮箱>"` 再跑 |
| 预览的正文**开头多了一行** `From: xxx` | 补丁作者 ≠ 发件人时 git 会往正文里插一行 `From:`。用同一个 `--identity` 生成+发送就不会有；脚本流程里不会发生 |
| `tools/preview-sendmail.sh: not found` | 包解压不完整，`tools/` 没跟过来（§10 有清单） |
| `--dry-run` 过了但 `--send` 失败 | `--dry-run` 不连 SMTP；单独测 SMTP，见 §3 |
| 脚本没有任何输出直接退出 | 看退出码：`./prepare-and-send.sh --check; echo $?` |

---

## 10. 包里有什么

```
prepare-and-send.sh          ← 主脚本（--check / --dry-run / --send / --update-ref）
commit-msg.txt               ← 补丁的 commit message（改这里）
cover-letter.txt             ← 封面信正文（改这里）
README-SUBMIT.md             ← 本文件
HOW-TO-SEND.md               ← 人工版操作说明 + reviewer 回信应对
REPORT.md                    ← 缺陷分析 + **我们的测试如何触发** + 证据链
0001-...patch                ← 静态参考件（黄金文件，脚本用来做回归比对）
alt/                         ← 方案 B（最小改动版），**不提交**，只存档
evidence/
  en_arfs.mainline.c         ← v7.4-rc2 的原始文件（补丁基线）
  en_arfs.patchedA.c         ← 打了方案 A 的成品（**要提交的就是它**）
  en_arfs.patchedB.c         ← 打了方案 B 的版本（存档）
  en_fs.mainline.c           ← en_fs.c（给 reviewer 核对调用链用）
  cve-2024-35835-fixupstream.patch  ← 回归来源 3c6d5189246f 的原始 diff
  review-v2-suggestion.txt   ← Simon Horman 建议 ft->num_groups = 0 的 review 原文
  review-v2-openwall.html    ← 上条的原始页面存档
  MAINTAINERS.mainline       ← v7.4-rc2 的 MAINTAINERS（收件人核对用）
tools/
  git-send-email             ← 自带的 git send-email（系统没有时用）
  perl/Mail/Address.pm       ← 上面那个脚本的依赖
  preview-sendmail.sh        ← --dry-run 用的假 sendmail：把整封邮件打到屏幕上
outgoing/                    ← 脚本生成物（每次跑都会重建）
work/  verify/               ← 脚本的临时目录（每次跑都会重建）
```

---

## 11. 一步到位（复制粘贴）

```bash
cd <本包目录>

# 1) 改身份和 SMTP
git config --global user.name  "Your Name"
git config --global user.email "your.real.mail@example.com"
git config --global sendemail.smtpserver smtp.example.com
git config --global sendemail.smtpport 587
git config --global sendemail.smtpauth PLAIN
git config --global sendemail.smtpuser your-account
git config --global sendemail.smtppass your-password
git config --global sendemail.smtpssl required

# 2) 自检（必须全绿）
./prepare-and-send.sh --check --identity "Your Name <your.real.mail@example.com>"

# 3) 干跑：把两封邮件的完整原文打到屏幕上，逐行读完
./prepare-and-send.sh --dry-run --identity "Your Name <your.real.mail@example.com>"

# 4) 真发（--to-extra 给自己留一份，netdev 规矩：第一次发先给自己一份）
./prepare-and-send.sh --send --identity "Your Name <your.real.mail@example.com>" \
    --to-extra "your.real.mail@example.com"
```
