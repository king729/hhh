#!/bin/sh
# 预览用：把 git send-email 交给「sendmail」的那封邮件原样打到 stdout。
#
# git send-email 自己的 --dry-run 只打邮件头，不打正文 —— 补丁正文才是要校对的
# 东西（空白、制表符、@@ 段一个都不能错），所以预览走这条 sendmail 路径：
# git 把 header + body 写进本脚本的 stdin，脚本 cat 到 stdout，**什么都不会发出去**。
#
# git send-email 会给 sendmail 传 -i/-t 之类的开关，普通 cat 不认这些开关会报错，
# 所以这里用 `exec cat`（不转发脚本自己的参数）把它当成纯 cat 用。

echo "════════════════════════════════════════════════════════════════════════"
echo "  ↓↓↓ 下面这一封邮件的完整原文（git send-email 即将发出的内容，未发送）"
echo "════════════════════════════════════════════════════════════════════════"
exec cat
