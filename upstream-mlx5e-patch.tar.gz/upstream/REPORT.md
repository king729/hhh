# 上游 bug 报告：mlx5e `arfs_create_groups()` 空指针解引用

> 结论：**是上游的真 bug**，v7.4-rc2 仍未修；回归由 CVE-2024-35835 的修复（`3c6d5189246f`）引入。
> 我们的测试通过「固件提前回错」把宿主推上了这条错误路径，两轮独立复现。

---

## 1. 缺陷本体

### 1.1 源码链（行号按 v6.18.9，本仓库 `/root/linux-6.18.9`）

`drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c`：

```c
253: static int arfs_create_groups(struct mlx5e_flow_table *ft, enum arfs_type type)
...
263: 	ft->g = kcalloc(MLX5E_ARFS_NUM_GROUPS, sizeof(*ft->g), GFP_KERNEL);
265: 	if (!ft->g)
266: 		return -ENOMEM;
268: 	in = kvzalloc(inlen, GFP_KERNEL);
269: 	if (!in) {
270: 		err = -ENOMEM;
271: 		goto err_free_g;
272: 	}
...
320: 	ft->g[ft->num_groups] = mlx5_create_flow_group(ft->t, in);   /* group 1 */
321: 	if (IS_ERR(ft->g[ft->num_groups]))
322: 		goto err_clean_group;
323: 	ft->num_groups++;                    /* <-- 变成 1 */

329: 	ft->g[ft->num_groups] = mlx5_create_flow_group(ft->t, in);   /* group 2 */
330: 	if (IS_ERR(ft->g[ft->num_groups]))
331: 		goto err_clean_group;
332: 	ft->num_groups++;

337: err_clean_group:
338: 	err = PTR_ERR(ft->g[ft->num_groups]);
339: 	ft->g[ft->num_groups] = NULL;
340: err_free_in:
341: 	kvfree(in);
342: err_free_g:
343: 	kfree(ft->g);
344: 	ft->g = NULL;        /* <-- num_groups 仍然是 1，没有复位 */
345: 	return err;
```

唯一调用者 `arfs_create_table()`（同文件 `:348`）：

```c
358: 	ft->num_groups = 0;
364: 	ft->t = mlx5_create_flow_table(ns, &ft_attr);
...
371: 	err = arfs_create_groups(ft, type);
372: 	if (err)
373: 		goto err;
...
380: err:
381: 	mlx5e_destroy_flow_table(ft);
382: 	return err;
```

`drivers/net/ethernet/mellanox/mlx5/core/en_fs.c`：

```c
870: static void mlx5e_destroy_groups(struct mlx5e_flow_table *ft)
871: {
872: 	int i;
873:
874: 	for (i = ft->num_groups - 1; i >= 0; i--) {
875: 		if (!IS_ERR_OR_NULL(ft->g[i]))          /* <-- ft->g == NULL ⇒ 解引用 NULL */
876: 			mlx5_destroy_flow_group(ft->g[i]);
877: 		ft->g[i] = NULL;
878: 	}
879: 	ft->num_groups = 0;
880: }
...
887: void mlx5e_destroy_flow_table(struct mlx5e_flow_table *ft)
888: {
889: 	mlx5e_destroy_groups(ft);
890: 	kfree(ft->g);
891: 	mlx5_destroy_flow_table(ft->t);
892: 	ft->t = NULL;
893: }
```

### 1.2 崩点

`ft->num_groups == 1`（group 1 建成功）而 `ft->g == NULL` ⇒ `mlx5e_destroy_groups()` 的循环体
`ft->g[0]` 解引用 NULL ⇒ oops。

**只有 group 2 失败才会触发**：group 1 自己失败时 `num_groups` 仍是 0，循环体一次都不执行。

### 1.3 附带缺陷：group 1 泄漏

`ft->g` 被 `kfree()` 掉，但**建成功的 group 1 从没被 `mlx5_destroy_flow_group()` 销毁**
（`mlx5_destroy_flow_table()` 只销毁表，不销毁 group；`del_sw_flow_table()`（`fs_core.c:585`）
只做 `rhltable_destroy(&ft->fgs_hash); kfree(ft);`）⇒ **firmware 侧的 flow group 泄漏**。

同驱动里正确的写法在 L2 路径（`en_fs.c:1089` 的 `err_destroy_groups:`）：
**先 `mlx5e_destroy_groups(ft)` 再 `kfree(ft->g)`**。
`en_accel/fs_tcp.c`、`en/fs_tt_redirect.c` 的错误路径也都保留 `ft->g` 不释放。
**ARFS 是唯一一条「释放了 `ft->g` 而 `num_groups` 还数着已建成的 group」的路径。**

### 1.4 回归来源：**是 CVE-2024-35835 的修复顺手引入的**

| 项 | 值 |
|---|---|
| 引入回归的提交 | `3c6d5189246f` 「net/mlx5e: fix a double-free in arfs_create_groups」（Zhipeng Lu，2024-01-24 进 v6.8） |
| 它修的 CVE | CVE-2024-35835（OOM 路径里 `ft->g` 被 free 但**没置 NULL**，调用者再 free 一次 ⇒ double free） |
| 它的做法 | 在错误路径加 `err_free_g: kfree(ft->g); ft->g = NULL;` |
| 漏掉的一步 | 顺手加 `ft->num_groups = 0;` |

**决定性证据 —— 该提交的 diff 本身**（`evidence/cve-2024-35835-fixupstream.patch`）：

```diff
--- a/drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
+++ b/drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
@@ -254,11 +254,13 @@ static int arfs_create_groups(struct mlx5e_flow_table *ft,
 	ft->g = kcalloc(MLX5E_ARFS_NUM_GROUPS,
 			sizeof(*ft->g), GFP_KERNEL);
-	in = kvzalloc(inlen, GFP_KERNEL);
-	if  (!in || !ft->g) {
-		kfree(ft->g);
-		kvfree(in);
+	if (!ft->g)
 		return -ENOMEM;
+
+	in = kvzalloc(inlen, GFP_KERNEL);
+	if (!in) {
+		err = -ENOMEM;
+		goto err_free_g;
+	}
...
@@ -318,18 +320,20 @@ static int arfs_create_groups(struct mlx5e_flow_table *ft,
 	kvfree(in);
 	return 0;
 
-err:
+err_clean_group:
 	err = PTR_ERR(ft->g[ft->num_groups]);
 	ft->g[ft->num_groups] = NULL;
-out:
+err_free_in:
 	kvfree(in);
-
+err_free_g:
+	kfree(ft->g);
+	ft->g = NULL;
 	return err;
 }
```

**读法（这是本报告最重要的一段）**：

| | 改之前 | 改之后（= 当前上游） |
|---|---|---|
| OOM 路径（`!in \|\| !ft->g`） | `kfree(ft->g)` 但**不置 NULL** ⇒ 调用者再 free ⇒ **double free**（= CVE-2024-35835） | `kfree(ft->g); ft->g = NULL;` ⇒ double free 修好 |
| **group 失败路径** | **`ft->g` 完全不动** ⇒ 调用者的 `mlx5e_destroy_groups()` 拿到有效数组，销毁已建成的 group，再释放数组 ⇒ **既不崩也不泄漏** | **`ft->g` 被释放并置 NULL** ⇒ **空指针解引用 + group 泄漏** |

⇒ **CVE 的修复只需要改 OOM 路径，却把 group 失败路径一起改了** ——
空指针解引用和 group 泄漏都是 `3c6d5189246f` **引入的回归**，
改之前的行为是对的。

**这个漏步在 review 里被明确提过、作者明确推迟了。** v2 review 线程
（[lists.openwall.net/netdev/2024/01/10/129](https://lists.openwall.net/netdev/2024/01/10/129)，
存档见 `evidence/review-v2-suggestion.txt`）里 Simon Horman 建议加 `ft->num_groups = 0;`：

> Although I suggested the above change, I think it
> probably suitable for a separate patch. For one thing,
> this is not mentioned in the patch subject. And for another,
> it's probably better to change one thing at a time.

作者回：

> Agree, I made this change because I'd like to apply as much
> suggestion as possible. And it is a better idea to leave it
> to a refector patch one day.

**最终合入的 `3c6d5189246f` 里没有 `ft->num_groups = 0;`** ——
v2 试过把它从 `arfs_create_table()` 挪进 `arfs_create_groups()`，最终版本又退回去了
（`ft->num_groups = 0;` 今天仍在 `arfs_create_table()` 里）。
⇒ **那个 "refactor patch" 一直没有落地。** CVE 修好了，NULL 解引用留下来了。

### 1.5 上游现状（2026-11-14）

- mainline 版本：**v7.4-rc2**（`Makefile`: `VERSION = 7 / PATCHLEVEL = 4 / SUBLEVEL = 0 / EXTRAVERSION = -rc2`）
- mainline 的 `en_arfs.c`（`raw.githubusercontent.com/torvalds/linux/master/...`）**逐字节仍是**
  ```c
  341: err_free_g:
  342: 	kfree(ft->g);
  343: 	ft->g = NULL;
  ```
  与本地 6.18.9 的差异**只有分配器 API 换代**（`kcalloc`→`kzalloc_obj`、`kvzalloc`→`kvzalloc_obj`），
  **错误路径本身逐字节相同**。
- 上游至今**没有**针对这个点的修复（netdev 列表上搜不到；`lore` 上只有 2025 年
  `mlx5e_tc_nic_create_miss_table` 的另一个空指针补丁，与本处无关）。

---

## 2. ★ 我们的测试如何触发的这个 bug

### 2.1 一句话

**我们的固件把宿主的 `CREATE_FLOW_GROUP` 命令提前判失败回给了宿主**（固件预算 2 s，
命令实际耗时 3662 ms，而宿主自己的预算是 60 s），宿主因此走进
`arfs_create_groups()` 的错误路径 —— 此时 **group 1 已建成功（`num_groups == 1`）而
group 2 失败** ⇒ 命中上游那条「`ft->g` 已被释放、`num_groups` 没复位」的空指针解引用。

### 2.2 完整触发链（步骤链）

```
① 宿主加载 mlx5e 驱动 → 网卡探测
   → mlx5e_probe → mlx5e_attach_netdev → mlx5e_init_nic_rx
   → mlx5e_create_flow_steering → mlx5e_arfs_create_tables(fs, rx_res, ntuple=true)
   aRFS 打开 ⇒ 每种 arfs_type 建一张 flow table，每张表建 2 个 flow group
   判据（宿主日志 s0_host_terminal_R107_20261114.txt）：
     L2946  [<ffffffff80843604>] mlx5e_arfs_create_tables+0x44c/0x5d8
     栈底   mlx5e_probe+0x48e/0x81c

② 第 1 张表的 group 1 建成功 ⇒ 固件侧 ft->num_groups = 1
   判据（客体日志 dh_riscv_R107_20261114.txt）：
     L9224  MSG_IN  ch=0 opcode=0x933 ...            ← CREATE_FLOW_GROUP 进固件
     L9234  NODE exec_zxvp ENTER: opcode=0x933
     L9242  NODE exec_zxvp EXIT:  opcode=0x933 cmd_ret=0 out_status=0x0   ← 成功
     L9278  MSG_OUT ch=0 opcode=0x933 cmd_ret=0x0 out_status=0x0 status_own=0x00

③ 第 2 个 group 的 CREATE_FLOW_GROUP（还是 opcode 0x933）进固件
   我们的固件在 exec_cmd_handler_by_zxvp() 里等这条命令的完成信号，
   当时预算是 K_MSEC(2000)，而宿主自己的预算是 60 s
   （MLX5_TO_CMD_MS = 60000，drivers/net/ethernet/mellanox/mlx5/core/lib/tout.c:17）
   ⇒ 固件在 2 s 时先超时
   判据（客体日志）：
     L9310  MSG_IN ch=0 opcode=0x933 ...
     L9350  NODE exec_zxvp ENTER: opcode=0x933       ← 之后再无对应的 EXIT

④ 这条命令设备侧实际耗时 3662 ms ⇒ 命令其实成功了，
   但固件已经按超时回错：cmd_ret = 0x6 / out_status = 0x6（FW_ERR）
   判据（客体日志）：
     L9406  [err][exec_cmd_handler_by_zxvp 137]: exec_cmd timeout!
     L9410  MSG_OUT ch=0 opcode=0x933 cmd_ret=0x6 out_status=0x6
     L9437  NODE4 WB_STATUS: dma_channel_done observed t_dma_done_ms=10915775
            delta_from_db_ms=3662          ← DMA 在 3662 ms 后才观测到 DONE
     L9439  MSG_OUT ch=0 opcode=0x933 cmd_ret=0x6 out_status=0x6 status_own=0x0c

⑤ 宿主收到 CREATE_FLOW_GROUP 的错误返回
   ⇒ mlx5_create_flow_group() 返回 ERR
   ⇒ arfs_create_groups() 走 err_clean_group:
        ft->g[1] = NULL
        → err_free_in: kvfree(in)
        → err_free_g:  kfree(ft->g); ft->g = NULL;      ← 数组被释放
   ⇒ 此时 ft->num_groups 仍然是 1（group 1 建成功了）

⑥ arfs_create_table() 的 err: → mlx5e_destroy_flow_table(ft)
   → mlx5e_destroy_groups(ft):
        for (i = ft->num_groups - 1; i >= 0; i--)   /* i = 0 */
            if (!IS_ERR_OR_NULL(ft->g[i]))            /* ft->g == NULL ⇒ 解引用 NULL */
   ⇒ 空指针解引用

⑦ Oops ⇒ Kernel panic - not syncing: Attempted to kill init!
   判据（宿主日志 s0_host_terminal_R107_20261114.txt）：
     L2924  Unable to handle kernel NULL pointer dereference at virtual address 0000000000000000
     L2927  Oops [#1]
     L2930  epc : mlx5e_destroy_groups+0x38/0x6c
     L2931   ra : mlx5e_destroy_flow_table+0x10/0x30
     L2943  status: 0000000200000120 badaddr: 0000000000000000 cause: 000000000000000d
     L2946  [<ffffffff80843604>] mlx5e_arfs_create_tables+0x44c/0x5d8
     L2984  Code: 89b3 40f9 e052 098e 7a7d a011 84be 3783 0109 97a6 (6398) 853a
     L2986  Kernel panic - not syncing: Attempted to kill init! exitcode=0x0000000b
```

### 2.3 寄存器与指令反证（证明崩在读 `ft->g`，不是别处）

- `struct mlx5e_flow_table`（`en/fs.h`）= `{ int num_groups; struct mlx5_flow_table *t; struct mlx5_flow_group **g; }`
  ⇒ **`g` 在偏移 16**。
- 宿主寄存器 dump：**`a5 = 0000000000000000`**、`s1 = 0000000000000000`，`a0 = s2 = ffffaf80e0b41040`（`ft` 指针）。
- `Code:` 窗口按 RISC-V `dump_instr()` 语义解析（`arch/riscv/kernel/traps.c`：从 `epc-20` 打印 12 个 u16，
  括号那个 = 落在 `epc` 上的那条；32 位指令 = `(high << 16) | low`），
  窗口里**唯一可解码的 32 位指令是 `ld a5, 16(a0)`** —— 即**从 `ft` 读偏移 16 处的 `ft->g`**。
  读出来是 0（`a5 = 0`）⇒ 接下来 `ft->g[0]` 必崩。**与 §1.1 的源码链完全对上。**

### 2.4 为什么必须有「group 1 成功、group 2 失败」这个前提

上游那处空指针解引用**只在 `num_groups >= 1` 时可达**。我们的现场正好满足：
L9278 那条 `cmd_ret=0x0` 就是 group 1 成功的证据，L9406 那条超时是 group 2 的证据。
**两条日志是同一个 `ft` 上的相邻两次 `CREATE_FLOW_GROUP`**（同一个 `cmdq_base=0x18e20d000`、同一个 ch=0）。

### 2.5 两轮独立复现

| 轮次 | 宿主日志 | 客体日志 | 固件超时 | 命令实际耗时 |
|---|---|---|---|---|
| **R89**（5 天前） | `r89_attempt1_s0_host_terminal.txt` L2924 / L2930 / L2943 / L2986 | `r89_attempt1_dh_riscv.txt` L7446 `exec_cmd timeout!` | 2000 ms | `delta_from_db_ms=5855`（L7479） |
| **R107**（本轮） | `s0_host_terminal_R107_20261114.txt` L2924 / L2930 / L2943 / L2986 | `dh_riscv_R107_20261114.txt` L9406 | 2000 ms | `delta_from_db_ms=3662`（L9437） |

两轮的宿主崩溃点完全一致（`mlx5e_destroy_groups+0x38/0x6c`，`badaddr = 0`，`a5 = 0`），
两轮的客体都是同一条 `opcode=0x933` 超时。

### 2.6 这个 bug 在**我们之外**也会发生（提交时要讲清）

我们的固件只是**触发器**，不是**成因**。任何让宿主在
「group 1 已建成功」之后拿到 `CREATE_FLOW_GROUP` 错误返回的场合都会崩：

- 设备固件真的拒绝这条命令（资源不足、非法参数、命令不被支持）；
- 网卡初始化期间命令超时（我们遇到的就是这一类）；
- 固件报错后宿主重试路径。

**上游的修复是必需的**：host 收到任何错误都直接 panic，属于宿主侧的健壮性缺陷。
同时，**我们自己的固件超时预算（2 s）也是缺陷** —— 宿主预算是 60 s，
固件提前 2 s 判失败会把「实际成功的命令」报成失败。这一条已在固件侧修复（预算改 30 s）。

### 2.7 复现配方（最小化）

1. aRFS 打开（`ethtool -C <dev> rxflowhash-indes ...`，或默认 `ntuple` 路径）。
2. 让**第 2 个** `CREATE_FLOW_GROUP`（opcode `0x933`）返回错误。
   最小手段：让固件在该命令上超时或返回错误码 —— 例如固件端 2 s 超时（我们的现场）。
3. 观察：`mlx5e_arfs_create_tables()` → `mlx5e_destroy_flow_table()` → `mlx5e_destroy_groups()`
   在 `ft->g[0]` 处空指针解引用 ⇒ oops ⇒ panic。

> 上游不会接受「靠别人的固件超时才能复现」作为唯一理由，所以上面的 2/3 步要写成
> 「任何 `CREATE_FLOW_GROUP` 失败」；我们只是**恰好**提供了一个稳定的触发源。

---

## 3. 修复方案

> **已定：提交方案 A。** 方案 B 移入 `alt/` 存档，不提交（仅在 reviewer 明确要求时作为 v2 备选）。

### 3.1 方案 A（**提交这个**）：把 `ft->g` 的释放交回调用者

```diff
--- a/drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
+++ b/drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
@@ -267,7 +267,7 @@
 	in = kvzalloc(inlen, GFP_KERNEL);
 	if (!in) {
 		err = -ENOMEM;
-		goto err_free_g;
+		goto err_free_in;
 	}
 
 	mc = MLX5_ADDR_OF(create_flow_group_in, in, match_criteria);
@@ -338,9 +338,6 @@
 	ft->g[ft->num_groups] = NULL;
 err_free_in:
 	kvfree(in);
-err_free_g:
-	kfree(ft->g);
-	ft->g = NULL;
 	return err;
 }
```

**为什么这样是安全的、且 CVE-2024-35835 依然被修好**：

| 错误点 | `ft->g` | `num_groups` | 调用者 `mlx5e_destroy_flow_table()` 的行为 | 结果 |
|---|---|---|---|---|
| `kcalloc` 失败（`:265`） | NULL | 0 | `mlx5e_destroy_groups()` 循环不执行；`kfree(NULL)` | 无 double free |
| `kvzalloc` 失败（`:269`） | 非 NULL | 0 | 同上 + `kfree(ft->g)` | **只 free 一次**（CVE-2024-35835 修复保持） |
| group 2 失败（`:330`） | 非 NULL | 1 | `mlx5e_destroy_groups()` 销毁 group 1、`num_groups=0`；再 `kfree(ft->g)` | **空指针解引用消失 + group 1 不再泄漏** |

- `ft->g` 现在**只**由 `mlx5e_destroy_flow_table()` 释放一次 ⇒ double free 不复现。
- 已建成的 group 由 `mlx5e_destroy_groups()` 销毁 ⇒ 泄漏一并修掉。
- 与同驱动 L2 路径（`en_fs.c:1089` `err_destroy_groups:`）的写法一致。
- `_mlx5e_cleanup_tables()`（`en_arfs.c:197`）跳过 `ft.t == NULL` 的表，而
  `mlx5e_destroy_flow_table()` 末尾置 `ft->t = NULL` ⇒ **不存在二次销毁**。
- `err_free_g:` 标签连同唯一的 `goto` 一起删除 ⇒ 不会有 `-Wunused-label`。

### 3.2 方案 B（**不提交**，存档于 `alt/`）：复位 `num_groups`

```diff
--- a/drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
+++ b/drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c
@@ -339,6 +339,7 @@
 err_free_in:
 	kvfree(in);
 err_free_g:
+	ft->num_groups = 0;
 	kfree(ft->g);
 	ft->g = NULL;
 	return err;
```

这正是 **Simon Horman 在 v2 review 里提过、被作者推迟的那一行**。

- 只修空指针解引用；**group 1 仍然泄漏**（`ft->g` 被释放，group 无人销毁）。
- 改动最小、最容易被接受，但留下泄漏。

### 3.3 两个方案都已本地 dry-run 验证

```
$ patch -p1 --dry-run < 0001-net-mlx5e-arfs-fix-NULL-deref-in-arfs_create_groups.patch
$ patch -p1 --dry-run < "0001-... (alt-minimal).patch"
⇒ 两个都 rc=0，hunk 偏移仅 1 行（6.18.9 vs mainline 的行号差）
```

---

## 4. 提交清单

包的根目录就是本文件所在目录（当前在 `/root/claude/tmp/upstream/`）。
**发送流程看 `README-SUBMIT.md`**，
本节只列文件。

| 文件 | 内容 |
|---|---|
| `README-SUBMIT.md` | **主文档**：三步走（`--check` → `--dry-run` → `--send`）、身份/SMTP 配置、自检项清单、排障、包里有什么 |
| `prepare-and-send.sh` | **主脚本**：生成补丁 + 逐项自检 + 收件人核对 + 发送。`--check` / `--dry-run` / `--send` / `--update-ref` / `--to-extra` |
| `commit-msg.txt` | 补丁的 commit message（**不含** `Signed-off-by:`，由 `git commit -s` 加） |
| `cover-letter.txt` | 封面信正文（6 节：缺陷 / 引入方式 / oops / 我们的触发 / 修法 / 范围） |
| `HOW-TO-SEND.md` | 补篇：脚本跑不了时的手工发送路径、人工过一遍清单、reviewer 回信应对 |
| `REPORT.md` | 本文件：缺陷分析 + **触发链** + 证据 |
| `0001-net-mlx5e-arfs-fix-NULL-deref-in-arfs_create_groups.patch` | **静态参考件（黄金文件）**：脚本拿它跟本次生成做逐字节比对，防止输入被手滑改掉。用 `--update-ref` 更新 |
| `evidence/en_arfs.mainline.c` | v7.4-rc2 的原始文件，**补丁的基线** |
| `evidence/en_arfs.patchedA.c` | 打了方案 A 的成品，**要提交的就是它** |
| `evidence/en_arfs.patchedB.c` | 打了方案 B 的版本（存档，不提交） |
| `evidence/en_fs.mainline.c` | `en_fs.c`，给 reviewer 核对调用链用 |
| `evidence/cve-2024-35835-fixupstream.patch` | **回归来源的原始证据**：`3c6d5189246f` 的完整 diff |
| `evidence/review-v2-suggestion.txt` | Simon Horman 建议 `ft->num_groups = 0;` 的 review 原文摘录（openwall 镜像） |
| `evidence/review-v2-openwall.html` | 上条的原始页面存档 |
| `evidence/MAINTAINERS.mainline` | v7.4-rc2 的 MAINTAINERS，脚本第 7 步用它复核收件人 |
| `tools/git-send-email` + `tools/perl/Mail/Address.pm` | 系统没装 `git send-email` 时的自带件及其依赖 |
| `tools/preview-sendmail.sh` | `--dry-run` 用的假 sendmail：把**整封邮件（头 + 正文）**打到屏幕上，什么都不发 |
| `alt/0001-... (alt-minimal).patch` | 方案 B，**不提交**，存档 |

**发之前只有一处必改**：`From:` / `Signed-off-by:` 的身份。
脚本用 `--identity "Your Name <you@example.com>"` 传进去，会自动填到两处
（补丁和封面信两处的 `From:` 都会填），并检查邮箱域名不是内网的
（`.intra` 之类直接报错拦下，且**拦下后一步都不发**）。

**收件人不是手写的**，是 `get_maintainer.pl` 对 v7.4-rc2 的 MAINTAINERS 跑出来的，
脚本每次跑都会自己复核一遍（见 `README-SUBMIT.md` §6）。

---

## 5. 边界（写进 cover letter 的诚实声明）

1. 我们的复现**依赖我们的固件在 `CREATE_FLOW_GROUP` 上超时**。这**不削弱**上游修复的必要性 ——
   任何错误返回都会触发同一个 oops；但 upstream reviewer 会问「不用你们的固件能否复现」，
   cover letter 里要正面回答：可以，用任何能让该命令失败的方式（固件拒绝、资源不足），
   我们的固件只是提供了一个**稳定、可重复**的触发源。
2. 我们**没有**在真机上跑过打了补丁的内核（我们的宿主是 QEMU + 虚拟 mlx5），
   补丁的正确性来自源码推理 + `patch --dry-run`，不是实测。
3. 上游现状核对基于 **v7.4-rc2**（2026-11-14 的 mainline 快照）。
