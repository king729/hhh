#!/bin/bash
# prepare-and-send.sh —— 上游 Linux 内核补丁（mlx5e aRFS 空指针解引用）的
#                          一键准备 + 自检 + 发送
#
# 用法:
#   ./prepare-and-send.sh --check      只做环境与内容自检，不生成补丁、不发送
#   ./prepare-and-send.sh --dry-run    生成补丁 + 自检 + 把两封邮件完整打到屏幕上（不真发）
#   ./prepare-and-send.sh --send       生成补丁 + 自检 + 真正发送
#   ./prepare-and-send.sh --update-ref 用本次生成覆盖静态参考件（改了输入之后承认新基线）
#
# 身份（决定 From: 和 Signed-off-by:）:
#   ./prepare-and-send.sh --identity "Your Name <you@example.com>" ...
#   KERNEL_IDENTITY="Your Name <you@example.com>" ./prepare-and-send.sh ...
#   两者都没有 ⇒ 读 git config user.name / user.email ⇒ 再没有就交互询问
#
# 其它可选参数:
#   --to-extra "you@example.com"   额外收件人，可重复（netdev 规矩：第一次发先给自己一份）
#   --update-ref                   用本次生成覆盖静态参考件（改了输入之后承认新基线）
#
# 退出码: 0 = 全部检查通过（--dry-run / --send 时表示邮件已进入发送流程）

set -euo pipefail

PKG="$(cd "$(dirname "$0")" && pwd)"
cd "$PKG"

# ── 常量 ────────────────────────────────────────────────────────────────────
BASE_COMMIT="97d73c8251226cf27cc6656b4c542869bb8c69fa"   # mainline tip（v7.4-rc2 之后）
BASE_COMMIT_DESC="mainline master tip, v7.4-rc2 + a few commits"
REL="drivers/net/ethernet/mellanox/mlx5/core/en_arfs.c"

# 收件人 = scripts/get_maintainer.pl -f --nogit 对 v7.4-rc2 的 MAINTAINERS 跑出来的结果，
# maintainer 进 To、list 进 Cc。推导命令见 README-SUBMIT.md §6；
# 步骤 7 会用包内自带的 evidence/MAINTAINERS.mainline 再跑一遍核对。
TO_ADDRS="saeedm@nvidia.com tariqt@nvidia.com mbloch@nvidia.com leonro@nvidia.com andrew+netdev@lunn.ch davem@davemloft.net edumazet@kernel.org kuba@kernel.org pabeni@redhat.com"
CC_ADDRS="netdev@vger.kernel.org linux-rdma@vger.kernel.org linux-kernel@vger.kernel.org"

BASE_FILE="evidence/en_arfs.mainline.c"      # v7.4-rc2 的原始文件
FIXED_FILE="evidence/en_arfs.patchedA.c"     # 打了方案 A 补丁的文件
REF_PATCH="0001-net-mlx5e-arfs-fix-NULL-deref-in-arfs_create_groups.patch"  # 静态参考件
VENDORED_SENDEMAIL="tools/git-send-email"

MODE=""
IDENTITY=""
UPDATE_REF=0
EXTRA_TO=""

# ── 参数 ────────────────────────────────────────────────────────────────────
while [ $# -gt 0 ]; do
	case "$1" in
		--check|--dry-run|--send) MODE="${1#--}" ;;
		--update-ref) UPDATE_REF=1 ;;
		--to-extra) EXTRA_TO="$EXTRA_TO ${2:-}"; shift ;;
		--identity) IDENTITY="${2:-}"; shift ;;
		--identity=*) IDENTITY="${1#*=}" ;;
		-h|--help) awk 'NR>1 && /^#/ {print; next} NR>1 && NF {exit}' "$0"; exit 0 ;;
		*) echo "未知参数: $1" >&2; exit 2 ;;
	esac
	shift
done
[ -n "$MODE" ] || MODE=check

# ── 小工具 ──────────────────────────────────────────────────────────────────
PASS=0; FAIL=0
ok()   { printf '  \033[32m✓\033[0m %s\n' "$*"; PASS=$((PASS+1)); }
bad()  { printf '  \033[31m✗\033[0m %s\n' "$*"; FAIL=$((FAIL+1)); }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
hdr()  { printf '\n\033[1m%s\033[0m\n' "$*"; }

# ── 0. 环境 ─────────────────────────────────────────────────────────────────
hdr "0. 环境"
command -v git   >/dev/null 2>&1 && ok "git: $(git --version)"        || bad "找不到 git"
command -v perl  >/dev/null 2>&1 && ok "perl: $(perl -e 'print $^V')" || bad "找不到 perl"

# 找 git send-email。git 找子命令的顺序是 exec-path 然后 PATH，所以两处都要查。
SEND_CMD=""
git_exec_path="$(git --exec-path 2>/dev/null || true)"
if [ -n "$git_exec_path" ] && [ -x "$git_exec_path/git-send-email" ]; then
	SEND_CMD="git send-email"; ok "git send-email: 系统自带（$git_exec_path/git-send-email）"
elif command -v git-send-email >/dev/null 2>&1; then
	SEND_CMD="git send-email"; ok "git send-email: 系统自带（$(command -v git-send-email)）"
elif [ -f "$VENDORED_SENDEMAIL" ]; then
	# 包内自带件：git master 的 git-send-email 需要 Mail::Address，
	# 而本包自带的依赖在 tools/perl 下，必须用 -I 指给 perl
	SEND_CMD="perl -I '$PKG/tools/perl' '$PKG/$VENDORED_SENDEMAIL'"
	ok "git send-email: 用包内自带件 $VENDORED_SENDEMAIL（依赖在 tools/perl）"
else
	bad "既没有系统 git send-email，也没有包内自带件"
fi
if [ -n "$SEND_CMD" ]; then
	# 自检：确认真能加载起来（依赖缺失会在这里暴露，而不是发到一半才炸）
	if perl -I "$PKG/tools/perl" -c "$PKG/$VENDORED_SENDEMAIL" >/dev/null 2>&1 \
	   || [ "$SEND_CMD" = "git send-email" ]; then
		:
	else
		warn "包内自带件自检没过（perl -c 失败），发之前先看下面的错误"
	fi
fi

# SMTP 配置：--send 时是硬要求，--check/--dry-run 只是提醒
if command -v git >/dev/null 2>&1; then
	smtp_cfg=$(git config --get sendemail.smtpserver || true)
	if [ -n "$smtp_cfg" ]; then
		ok "SMTP: sendemail.smtpserver = $smtp_cfg"
		for k in smtpuser smtppass smtpauth smtpssl smtpport; do
			v=$(git config --get "sendemail.$k" || true)
			[ -n "$v" ] && ok "SMTP: sendemail.$k = $([ "$k" = smtppass ] && echo '<已设>' || echo "$v")"
		done
	elif [ "$MODE" = "send" ]; then
		bad "SMTP: 没设 sendemail.smtpserver，--send 会失败（见 README-SUBMIT.md §3）"
	else
		warn "SMTP: 未设 sendemail.smtpserver（--send 前需配好，见 README-SUBMIT.md §3）"
	fi
fi

# ── 1. 身份 ─────────────────────────────────────────────────────────────────
hdr "1. 身份"
if [ -z "$IDENTITY" ]; then
	IDENTITY="${KERNEL_IDENTITY:-}"
fi
if [ -z "$IDENTITY" ]; then
	git_email=$(git config --get user.email || true)
	git_name=$(git config --get user.name || true)
	if [ -n "$git_email" ]; then
		IDENTITY="${git_name:-$git_email} <$git_email>"
	fi
fi
if [ -z "$IDENTITY" ] && [ "$MODE" != "check" ]; then
	printf '  请输入提交者身份（名字 <邮箱>）: '
	read -r IDENTITY
fi
if [ -n "$IDENTITY" ]; then
	NAME="${IDENTITY%%<*}"; NAME="$(echo "$NAME" | sed 's/[[:space:]]*$//')"
	MAIL="${IDENTITY##*<}";  MAIL="${MAIL%%>*}"
	if [ -n "$MAIL" ] && [ -n "$NAME" ]; then
		ok "身份: $NAME <$MAIL>"
		case "$MAIL" in
			*@*.*) : ;;
			*) warn "邮箱看起来不像合法地址: $MAIL" ;;
		esac
		# 内网域名发到 LKML 上没人收得到 —— 这是最容易犯的错，单拎出来警告
		case "$MAIL" in
			*.intra|*.internal|*.local|*.lan|*.localdomain)
				bad "邮箱域名是内网的，外网收不到 —— 必须换成能收信的地址" ;;
		esac
	else
		bad "身份格式不对（要 '名字 <邮箱>'）: $IDENTITY"
	fi
else
	bad "没有身份。--check 时可跳过；--send 时用 --identity \"名字 <邮箱>\" 指定"
fi

# ── 2. 素材齐备 ─────────────────────────────────────────────────────────────
hdr "2. 素材"
for f in "$BASE_FILE" "$FIXED_FILE" "$REF_PATCH" commit-msg.txt cover-letter.txt; do
	[ -f "$f" ] && ok "$f" || bad "缺 $f"
done

# ── 3. 生成补丁（--check 时也生成，好让后面的检查有实物） ──────────────────
hdr "3. 生成补丁"
rm -rf work outgoing
mkdir -p work/"$(dirname "$REL")" outgoing
cp "$BASE_FILE" "work/$REL"
(
	cd work
	git init -q .
	git add -A
	git -c user.email="build@localhost" -c user.name="build" \
		commit -q -m "base: mainline en_arfs.c (v7.4-rc2)"
	cp "../$FIXED_FILE" "$REL"
	git add -A
	git -c user.email="${MAIL:-build@localhost}" -c user.name="${NAME:-build}" \
		commit -q -s -F ../commit-msg.txt
	# format-patch 造封面信那一步读的是「仓库级 ident」，-c user.email=... 管不到它，
	# 不设的话封面信的 From: 会变成本机 git 身份（发出去就是别人收不到的内网地址）。
	git config user.email "${MAIL:-build@localhost}"
	git config user.name "${NAME:-build}"
	git format-patch --cover-letter --subject-prefix='PATCH net' \
		-1 HEAD -o ../outgoing/ >/dev/null
)
ok "git format-patch 完成"

PATCH1=""
for f in outgoing/0001-*.patch; do
	[ -f "$f" ] && { PATCH1="$f"; break; }
done
[ -n "$PATCH1" ] && ok "生成: $PATCH1" || bad "没生成 0001 补丁"
COVER="outgoing/0000-cover-letter.patch"
[ -f "$COVER" ] && ok "生成: $COVER" || bad "没生成 0000 封面信"

# ── 4. 把封面信填上 ────────────────────────────────────────────────────────
hdr "4. 封面信"
if [ -f "$COVER" ]; then
	COVER_SUBJECT="[PATCH net 0/1] net/mlx5e: fix NULL pointer dereference in arfs_create_groups()"
	python3 - "$COVER" "$COVER_SUBJECT" <<'PY'
import sys, re
path, subject = sys.argv[1], sys.argv[2]
body = open('cover-letter.txt', encoding='utf-8').read().rstrip() + '\n'
t = open(path, encoding='utf-8').read()
t = re.sub(r'^Subject: .*\*\*\* SUBJECT HERE \*\*\*$', 'Subject: ' + subject,
           t, flags=re.M)
t = t.replace('*** BLURB HERE ***', body.rstrip())
# base-commit trailer：放在签名之前（内核文档 submitting-patches.rst 的要求）
t = re.sub(r'\n(-- \n)', '\nbase-commit: 97d73c8251226cf27cc6656b4c542869bb8c69fa\n\\1', t)
open(path, 'w', encoding='utf-8').write(t)
PY
	ok "主题: $COVER_SUBJECT"
	ok "正文已填入 cover-letter.txt"
	grep -q '^base-commit: 97d73c8251226cf27cc6656b4c542869bb8c69fa' "$COVER" \
		&& ok "base-commit trailer 已加（$BASE_COMMIT_DESC）" \
		|| bad "base-commit trailer 没加上"
	grep -q '\*\*\* SUBJECT HERE \*\*\*\|\*\*\* BLURB HERE \*\*\*' "$COVER" \
		&& bad "封面信里还有占位符没替换" \
		|| ok "占位符已全部替换"
	# 封面信的 From: 必须也是你 —— 错成别人（尤其是本机内网身份）这封信就没人认领
	if [ -n "$MAIL" ]; then
		grep -qF "From: $NAME <$MAIL>" "$COVER" \
			&& ok "封面信 From: 与身份一致" \
			|| bad "封面信 From: 不是你的身份（实际：$(grep -m1 '^From:' "$COVER")）"
	fi
fi

# ── 5. 内容自检 ─────────────────────────────────────────────────────────────
hdr "5. 内容自检"
if [ -n "$PATCH1" ]; then
	# 主题长度
	slen=$(grep -m1 '^Subject:' "$PATCH1" | sed 's/^Subject: //' | awk '{print length($0)}')
	[ "$slen" -le 75 ] && ok "主题 $slen 列（≤75）" || bad "主题 $slen 列，超过 75"

	# 正文行宽
	long=$(awk '/^$/{b=1} b && /^ /{if(length($0)>76) c++} END{print c+0}' "$PATCH1")
	[ "$long" = "0" ] && ok "正文无超过 75 列的行" || bad "正文有 $long 行超过 75 列"

	# 必需 trailer
	grep -q '^Fixes: 3c6d5189246f ' "$PATCH1" && ok "有 Fixes: 指向引入回归的提交" || bad "缺 Fixes:"
	grep -q '^Signed-off-by: ' "$PATCH1" && ok "有 Signed-off-by:" || bad "缺 Signed-off-by:"
	if grep -q '^Signed-off-by: ' "$PATCH1" && [ -n "$MAIL" ]; then
		grep -qF "Signed-off-by: $NAME <$MAIL>" "$PATCH1" \
			&& ok "Signed-off-by 与身份一致" \
			|| bad "Signed-off-by 与身份不一致"
	fi
	grep -q '^Tested-by: ' "$PATCH1" && bad "有 Tested-by:（我们没跑过打了补丁的内核，这是假声明，删掉）" || ok "没有 Tested-by:（正确）"

	# 与静态参考件比对：只允许身份行不同
	# --update-ref：拿本次生成的覆盖参考件（= 承认这一版是新的基线）
	if [ "$UPDATE_REF" = "1" ]; then
		cp "$PATCH1" "$REF_PATCH"
		ok "已更新静态参考件: $REF_PATCH"
	elif [ -f "$REF_PATCH" ]; then
		if python3 - "$PATCH1" "$REF_PATCH" <<'PY'
import sys, re
def norm(p):
    t = open(p, encoding='utf-8', errors='replace').read()
    t = re.sub(r'^(From|From:).*$', r'\1: <ID>', t, flags=re.M)
    t = re.sub(r'^Signed-off-by:.*$', 'Signed-off-by: <ID>', t, flags=re.M)
    t = re.sub(r'^Date:.*$', 'Date: <DATE>', t, flags=re.M)
    t = re.sub(r'^Message-Id:.*$', 'Message-Id: <MID>', t, flags=re.M)
    t = re.sub(r'^From [0-9a-f]{40}.*$', 'From <SHA>', t, flags=re.M)
    t = re.sub(r'^--- \n.*\n', '--- \n<VERSION>\n', t)
    return t
a, b = norm(sys.argv[1]), norm(sys.argv[2])
if a == b:
    print("  \033[32m✓\033[0m 生成的补丁与静态参考件一致（除身份/日期/版本号）")
    sys.exit(0)
import difflib
d = list(difflib.unified_diff(b.splitlines(), a.splitlines(), '参考件', '生成件', lineterm=''))
print("  \033[31m✗\033[0m 生成的补丁与静态参考件有出入：")
print("   （输入改了？确实要改就在 commit-msg.txt / cover-letter.txt / evidence/ 里改，")
print("     改完用 --update-ref 承认新基线）")
for l in d[:40]:
    print('   ', l)
sys.exit(1)
PY
		then PASS=$((PASS+1)); else FAIL=$((FAIL+1)); fi
	else
		bad "缺静态参考件 $REF_PATCH（用 --update-ref 生成）"
	fi

	# 能否干净应用到 mainline
	rm -rf verify && mkdir -p verify/"$(dirname "$REL")"
	cp "$BASE_FILE" "verify/$REL"
	( cd verify && git init -q . && git add -A \
		&& git -c user.email=v@localhost -c user.name=v commit -q -m base \
		&& git apply --check "../$PATCH1" ) \
		&& ok "能干净应用到 mainline 的 en_arfs.c" \
		|| bad "不能干净应用到 mainline 的 en_arfs.c"
fi

# ── 6. checkpatch（内核自己的风格检查器） ─────────────────────────────────
hdr "6. checkpatch"
CP=""
for c in "${CHECKPATCH:-}" /root/linux-*/scripts/checkpatch.pl /usr/src/linux*/scripts/checkpatch.pl; do
	[ -f "$c" ] && { CP="$c"; break; }
done
if [ -n "$CP" ]; then
	out=$(perl "$CP" --no-tree --terse --patch "$PATCH1" 2>&1 || true)
	# "Unknown commit id" 是本地树没有那个 commit 造成的，不是真问题
	real=$(echo "$out" | grep -v "Unknown commit id" || true)
	if echo "$real" | grep -qE "^(total: [1-9]|.*: (ERROR|WARNING|CHECK))"; then
		echo "$real" | sed 's/^/    /'
		warn "checkpatch 有意见（见上），发之前请看一遍"
	else
		ok "checkpatch: 0 errors（Unknown commit id 是本地树没有该 commit，不是问题）"
	fi
else
	warn "没找到 scripts/checkpatch.pl，跳过（装个 kernel 源码树即可：apt install linux-source）"
fi

# ── 7. 收件人 ───────────────────────────────────────────────────────────────
hdr "7. 收件人"
printf '  To:\n'
for a in $TO_ADDRS; do printf '    %s\n' "$a"; done
printf '  Cc:\n'
for a in $CC_ADDRS; do printf '    %s\n' "$a"; done

# 用包内自带的 v7.4-rc2 MAINTAINERS 跑一遍 get_maintainer.pl，核对收件人还准不准
GM=""
for c in "${GET_MAINTAINER:-}" /root/linux-*/scripts/get_maintainer.pl /usr/src/linux*/scripts/get_maintainer.pl; do
	[ -f "$c" ] && { GM="$c"; break; }
done
if [ -z "$GM" ]; then
	warn "没找到 scripts/get_maintainer.pl，跳过收件人核对"
elif [ ! -f evidence/MAINTAINERS.mainline ]; then
	warn "缺 evidence/MAINTAINERS.mainline，跳过收件人核对"
else
	gm_tmp="$(mktemp -d)"
	# get_maintainer.pl 认这堆标志文件/目录才肯把当前目录当内核树
	for f in COPYING CREDITS Kbuild README Makefile; do : > "$gm_tmp/$f"; done
	for d in Documentation arch fs include init ipc kernel lib scripts; do mkdir -p "$gm_tmp/$d"; done
	cp evidence/MAINTAINERS.mainline "$gm_tmp/MAINTAINERS"
	mkdir -p "$gm_tmp/$(dirname "$REL")"
	cp "$BASE_FILE" "$gm_tmp/$REL"
	gm_out="$(cd "$gm_tmp" && perl "$GM" -f --nogit "$REL" 2>/dev/null || true)"
	rm -rf "$gm_tmp"
	# 带 "(maintainer:" 的是 To，带 "(open list" 的是 Cc
	# maintainer 行的地址在 <> 里；list 行的地址是裸的（行首第一个词）
	# grep 无匹配返回 1，管道里必须兜住，否则 set -e 会把脚本掐掉
	gm_to="$(echo "$gm_out" | grep '(maintainer:' | grep -o '<[^>]*>' | tr -d '<>' | tr '\n' ' ' || true)"
	gm_cc="$(echo "$gm_out" | grep '(open list' | sed 's/[[:space:]].*$//' | tr '\n' ' ' || true)"
	norm() { echo $1 | tr ' ' '\n' | sort | tr '\n' ' '; }
	if [ "$(norm "$gm_to")" = "$(norm "$TO_ADDRS")" ] && [ "$(norm "$gm_cc")" = "$(norm "$CC_ADDRS")" ]; then
		ok "收件人与 get_maintainer.pl(v7.4-rc2 MAINTAINERS) 的输出一致"
	else
		bad "收件人与 get_maintainer.pl 的输出不一致"
		printf '    MAINTAINERS To: %s\n' "$(norm "$gm_to")"
		printf '    本包    To: %s\n' "$(norm "$TO_ADDRS")"
		printf '    MAINTAINERS Cc: %s\n' "$(norm "$gm_cc")"
		printf '    本包    Cc: %s\n' "$(norm "$CC_ADDRS")"
	fi
fi

# ── 8. 发送 ────────────────────────────────────────────────────────────────
hdr "8. 发送"
if [ "$MODE" = "check" ]; then
	echo "  --check：到此为止，不生成也不发送。"
elif [ "$FAIL" -gt 0 ]; then
	# 前面有检查没过 ⇒ 一步都不往下走。
	# （身份是内网邮箱、SMTP 没配、补丁跟参考件不一致 …… 任何一条都不能带着发出去）
	echo "  前面有 $FAIL 项检查没过，不发送。退出码 1。"
	exit 1
elif [ -z "$SEND_CMD" ]; then
	bad "没有 git send-email，发不了"
	exit 1
else
	SEND_ARGS=""
	for a in $TO_ADDRS; do SEND_ARGS="$SEND_ARGS --to=$a"; done
	for a in $CC_ADDRS; do SEND_ARGS="$SEND_ARGS --cc=$a"; done
	for a in $EXTRA_TO; do SEND_ARGS="$SEND_ARGS --to=$a"; done
	if [ -n "$IDENTITY" ]; then SEND_ARGS="$SEND_ARGS --from=\"$IDENTITY\""; fi

	# --suppress-cc=self：不让 git 把作者（= 你自己）自动塞进 Cc。
	# 这样 Cc 严格等于 get_maintainer.pl 算出来的三个列表，邮件头可复现、可逐字核对。
	# 副作用：git 自己的确认提示随之消失（confirm 自动变成 compose），
	# 所以下面那个 yes 是唯一的闸门。
	SEND_ARGS="$SEND_ARGS --suppress-cc=self"

	if [ "$MODE" = "dry-run" ]; then
		# git 自己的 --dry-run 只打邮件头、不打正文；补丁正文才是最需要校对的
		# （空白、制表符、@@ 段一个都不能错），所以预览走 sendmail 路径：
		# 包内的 cat 包装把整封邮件（头 + 正文）原样打出来，什么都不会发出去。
		# 用相对路径：git-send-email 是 sh -c 起它的，路径里不能有空格；
		# 脚本开头 cd 过 $PKG，所以相对路径是稳的。
		SEND_ARGS="$SEND_ARGS --sendmail-cmd=tools/preview-sendmail.sh"
	fi

	echo "  命令:"
	echo "    $SEND_CMD \\"
	echo "      $SEND_ARGS \\"
	echo "      $COVER $PATCH1"
	echo
	if [ "$MODE" = "send" ]; then
		printf '  \033[31m这一步会真的把邮件发出去。\033[0m\n'
		printf "  确认发送？输入 yes 继续: "
		read -r ans
		[ "$ans" = "yes" ] || { echo "  已取消。"; exit 1; }
	fi
	eval $SEND_CMD $SEND_ARGS "\"$COVER\"" "\"$PATCH1\""
	echo
	if [ "$MODE" = "dry-run" ]; then
		ok "预览结束：上面是两封邮件的完整内容，没有发出去"
	else
		ok "已交给 git send-email"
	fi
fi

# ── 汇总 ────────────────────────────────────────────────────────────────────
hdr "汇总"
printf '  通过 %d 项，失败 %d 项\n' "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ] || exit 1
exit 0
